import UIKit

//===========================================================
//                          BUCLES
//===========================================================

/**
 
 Los bucles (o ciclos) se utilizan para repetir un bloque de código varias veces.
 
 */

var daysOfWeeks:[String] = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"]


// > BUCLE FOR
for i in 1...7{ // Recorres un número de codigo muchas veces
    print("Hola")
}

// Buscar en que posicion esta la palabra x y retornar
for i in daysOfWeeks {
    if i == "Jueves" {
        print("El día de hoy es \(i)") // De esta manera estamos recorriendo listados
    }
}



// > BUCLE WHILE. Se usará hasta esperar cuando una condicion sea verdadera

var count = 0

while count < 10 {
    print("Hola soy count y valgo \(count)")
    count += 1
}



// > BUCLE WHILE REPEAT. El código se ejecuta al menos una vez porque la condición se evalúa al final de la iteración.

var count1 = 5
repeat{
    print("Hola")
} while count1 < 0


for i in daysOfWeeks {
    if i == "Jueves" {
        print("El día de hoy es \(i)") // De esta manera estamos recorriendo listados
        break // Con este rompemos el bucle para que no siga buscando más
//        continue // Lo que hacemos es terminar hasta ahí y saltar al siguiente
    } else {
        print("No es jueves")
    }
}
