import UIKit

//===========================================================
//                      CLASES Y STRUCTS
//===========================================================

/**
 
 Tanto las Clases (class) como las Estructuras (struct) sirven para crear tus propios tipos de datos con propiedades y métodos.
 
 > Estructuras (struct)
 
 Son tipos de valor. Cuando asignas una estructura a una nueva variable, se crea una copia completa de los datos. Ideales para datos simples, modelos de datos de tu app (como un Usuario, Producto, Coordenada).

 > Clases (class)
 Son tipos de referencia. Cuando asignas una clase a una nueva variable, ambas apuntan al mismo objeto en la memoria.
 Ideales paraoObjetos que necesitan compartir un estado único (como un GestorDeBaseDeDatos o un ControladorDeVista). Una clase puede heredar de otra (usar super.algo).

 */


// CLASES. Son un molde, creamos un molde y mandandole atributos podemos crear otros moldes.

// Esto es el molde para crear a una persona
class Persona {
    var name:String
    var age:Int
    
    // Esto es un constructor
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
    func saludar() {
        print("Hola, soy \(name) y tengo \(age) años.")
    }
}

// Si queremos tener varias personas se hace a traves de los "Objetos". Si yo quiero crear una instancia (un objeto de tipo persona)

var mafer:Persona = Persona(name: "Fernanda Garcia", age: 20) // Ese es un objeto de tipo persona

var Karina:Persona = Persona(name: "Karina Silva", age: 21)

mafer.saludar()
Karina.saludar()

// Estamos creando una clase con distintas instancias de esta.




// STRUCT. Es una forma de almacenar información. Son clases más pequeñas para funcionalidade so cosas más especificas

struct ExampleStructure {
    var name:String
    var age:Int
}

var exampleStructure:ExampleStructure = ExampleStructure(name: "Fernanda", age: 20)

print(exampleStructure.age)
