import UIKit

//===========================================================
//                          CONDICIONALES
//===========================================================

/**
 
 Básicamente, son las que le permiten a tu código "tomar decisiones". En lugar de ejecutar todo de arriba hacia abajo de forma lineal, los condicionales le dicen al programa: "Si pasa esto, haz aquello; si no, haz esto otro".
 
 */

// > IF-ELSE

let userAge = Int.random(in: 1...30) // Aquí definimos un número aleatorio del 1-30

if userAge >= 18 {
    print("Eres mayor de edad (\(userAge))")
} else {
    print("Eres menor de edad (\(userAge))")
}




func greeting(_ hour:Int){
    if hour < 12 {
        print("Buenos días")
    } else if hour < 18{
        print("Buenas tardes")
    } else {
        print("Buenas noches")
    }
}
greeting(18)




func getMonth(month:Int){
    if month == 1 {
        print("Enero")
    } else if month == 2 {
        print("Febrero")
    } else if month == 3 {
        print("Marzo")
    } else if month == 4 {
        print("Abril")
    } else if month == 5 {
        print("Mayo")
    } else if month == 6 {
        print("Junio")
    } else if month == 7 {
        print("Julio")
    } else if month == 8 {
        print("Agosto")
    } else if month == 9 {
        print("Septiembre")
    } else if month == 10 {
        print("Octubre")
    } else if month == 11 {
        print("Noviembre")
    } else if month == 12{
        print("Diciembre")
    } else {
        print("Número de mes invalido.")
    }
}

getMonth(month: 17)




// > SWITCH

func monthWithSwitch(_ month:Int){
    switch month{
    case 1: print("Enero")
    case 2: print("Febrero")
    case 3: print("Marzo")
    case 4: print("Abril")
    case 5: print("Mayo")
    case 6: print("Junio")
    case 7: print("Julio")
    case 8: print("Agosto")
    case 9: print("Septiembre")
    case 10: print("Octubre")
    case 11: print("Noviembre")
    case 12: print("Diciembre")
    default: print("Introdue mes valido.")
    }
}
monthWithSwitch(3)




func getTrimestres(_ month:Int){
    switch month{
    case 1, 2, 3: print("Primer Trimestres") // Aqui estamos agrupando casos
    case 4, 5, 6: print("Segundo Trimestre")
    case 7, 8, 9: print("Tercer Trimestre")
    case 10, 11, 12: print("Cuarto Trimestre")
    default: print("Introdue mes valido.")
    }
}
getTrimestres(8)




func millones(_ numero:Int){
    switch numero {
    case 1...10: print("Rango 1 al 10") // Aqui aplicamos rangos
    case 11...1000: print("Rango 11 al 1000")
    default: print("Introduce un número dentro de los rangos")
    }
}
