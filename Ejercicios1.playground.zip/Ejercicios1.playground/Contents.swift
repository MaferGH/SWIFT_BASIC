import UIKit

/**
 Ejercicio 1. Registro de asisitencia
 
 Declara una variable "asistencias" y asignale un número de asistencias a una clase.
 Declara una variable "totalClases" y asignale el número total de clases.
 Cálcula el procentaje de asistencias utilizando la  fórmula:
                    Porcentaje = (Asistencias / TotalClases) x 100
 Imprime el porcentaje de asistencias
 */

let asistencias:Int = 20
let totalClases:Int = 40

let porcentaje:Float = (Float(asistencias) / Float(totalClases)) * 100

print("El resultado de asistencia es de: \(porcentaje)")


/**
 Ejercicio 2. Calculadora de IMC (Índice de Masa Corporal)
 
 Declara dos variables:
        - Peso (kg)
        - Altura (m)
 Calcula el IMC utilizando la fórmula:
                    IMC = peso / (altura x altura)
 Imprime el reusltado
 */

let peso:Float = 50
let altura:Float = 1.65

let imc:Float = peso / (altura * altura)
print("Tu IMC es de: \(imc)")


/**
 Ejercicio 3. Cálculo de Descuento
 Declara dos variables:
        - Precio Original
        - Porcentaje Descuento
 Cálcula el precio despues del descuento utilizando la formula:
            PrecioDescuento = PrecioOriginal - (PrecioOriginal x PorcentajeDescuento / 100)
 Imprime el precio original y el precio con descuento
 */

let precioOriginal:Float = 1999
let porcentajeDescuento:Float = 20

let precioDescuento:Float = precioOriginal - (precioOriginal * porcentajeDescuento / 100)
print("El precio Original de la camisa es de \(precioOriginal). Sin embargo, tiene un descuento de \(porcentajeDescuento)%, por lo que su precio con descuento seria de: \(precioDescuento)")
