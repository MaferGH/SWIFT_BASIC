import UIKit

/**
Ejercicio 4. Cálcular el área de un circulo
 
 Crea una función que reciba el radio de un círculo y devuelva su área.
 Usa la formula:
                            (PI x Radio x Radio)
 Luego imprime el resultado.
 */

func area(_ radio:Float) -> Float{
    return Float.pi * radio * radio
}
var result = area(10)
print("El área del circulo es de \(result)")




/**
 Ejercicio 5.
 
 Crea una función que recibe un número y con la ayuda de un IF imprime en pantalla si el número es positivo, negativo o cero
 */

func numeroEntero(_ num:Int){
    if num < 0 {
        print("El número \(num) es negativo")
    } else if num == 0 {
        print("El número \(num) es cero")
    } else if num > 0 {
        print("El número \(num) es positivo")
    }
}

numeroEntero(-2)




/**
 Ejercicio 6.
 
 Crea una función que recibe un número y con la ayuda de un SWICH imprime en pantalla si el número es positivo, negativo o cero
 */

func numeroEnteroWithSwich(_ numero:Int){
    switch numero {

// --------- NOTA: Para hacer condiciones con switch usar let y where --------
        
    case let numero where  numero < 0: print("El número \(numero) es negativo")
    case let numero where numero > 0: ("El número \(numero) es positivo")
    case let numero where numero == 0: ("El número \(numero) es cero")
    default:
        ("Introduce un número entero.")
    }
}
numeroEnteroWithSwich(12)
