import UIKit

/**
Ejercicio 7.
 
Escribe una función que reciba un número e imprime su tabla de multilicar del 1 al 10
 */

func tablaMultiplicar(_ numero: Int) {
    for i in 1 ... 10{
        var mult = numero * i
        print("\(numero) * \(i) = \(mult)")
    }
}
tablaMultiplicar(2)




/**
 Ejercicio 8.
 
 Escribe un programa que calcule la suma de todos los números pares del 1 al 100 y muestre el resultado .
 Nota: Para saber si un número es par se tiene que dar la siguiente condición (número % 2 == 0)
 */

var total = 0
for i in 1...100{
    if i % 2 == 0 {
        total += i
    }
}
print(total)




/**
 Ejercicio 9.
 
 Escribe una función que cuente el número de vocales en una palabra y lo imprima.
 Tips: La palabra string puede recorerce con bucle for
 */

func contarVocales(_ palabra: String) {
    var totalVocal:Int = 0
    for caracter in palabra{
        switch caracter.lowercased(){ // lo que hace lowercased() es pasar a minúscula
        case "a", "e", "i", "o", "u": totalVocal += 1
        default: continue
        }
    }
    print("Total de vocales que hay en la palabra \(palabra) es de \(totalVocal)")
}

contarVocales("hola")
