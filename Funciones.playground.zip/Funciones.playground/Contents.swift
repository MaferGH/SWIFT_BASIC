import UIKit

//===========================================================
//                          FUNCIONES
//===========================================================

/**
 
 Tambien cococido como métodos, es un bloque de código independiente que realiza una tarea específica. Se utilizan para agrupar lógica que quieres reutilizar en diferentes partes de tu aplicación sin tener que repetir el código.
 
 Su estructura es:
               |  func example ( ) {
               |      //Código que podemos reutilizar en todas partes
               |  }
 
 Para mejorar estas funciones se usan parametros de entrada y de salida
 
 */

// > PARAMETROS DE ENTRADA

func showMyName(){
    print("Hola es mi primera funcion")
}
showMyName() //Aquí mandamos a llama la función




func showMyCustomName(nombre:String){ // "nombre:String" es una variable
    print("Hola es \(nombre)")
}
showMyCustomName(nombre: "Mafer")




func calculate(a:Int, b:Int){
    let result = a + b
    print("El reusltado es: \(result)")
}
calculate(a: 10, b: 20)




func calculate2(_ a:Int, _ b:Int){ //La barra baja funciona para no poner nombre cuando lo mandamos a llamar
    let result = a + b
    print("El reusltado es: \(result)")
}
calculate2(40, 20)




// > PARAMETROS DE SALIDA

func calculate3(a:Int, b:Int) -> Int{ // "->" con ese decimos que retornamos
    let result = a + b
    return result // Para retornar usamos "return"
}
let superResult:Int = calculate3(a: 4, b: 7)
print(superResult)
