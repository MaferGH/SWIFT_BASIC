import UIKit

//===========================================================
//                          TUPLAS
//===========================================================

/**
 
 Es una forma sencilla de agrupar varios valores en un solo valor compuesto. A diferencia de un arreglo (Array), los valores dentro de una tupla pueden ser de distintos tipos y tienen un tamaño fijo una vez definidos.
 
 Es ideal para devolver múltiples valores de una función sin tener que crear una clase o estructura compleja.

 */

// > TUPLA POR POSICIÓN. Puedes acceder a los valores usando un índice

let persona = ("Mafer", 20, true, "Calle mi casa", 5514141414, 1.68)
print(persona.0) // "Juan"
print(persona.1) // 30




// > TUPLA ETIQUETADA. Es la forma más recomendada porque hace el código más legible.

let usuario = (nombre: "Elena", edad: 25, esPremium: true)
print(usuario.nombre) // "Elena"
print(usuario.esPremium) // true




// > DESCOMPOSICIÓN DE TUPLAS. Puedes extraer los valores de una tupla directamente en variables individuales

let (nombre, edad) = ("Carlos", 40)
print(nombre) // "Carlos"




//===========================================================
//                        DICCIONARIOS
//===========================================================


/**
 
 Es una colección que guarda parejas de clave-valor. A diferencia de un arreglo, los elementos no tienen un orden específico; se accede a ellos usando su clave (que debe ser única).
 
 Es como un diccionario real: buscas una palabra (la clave) para encontrar su definición (el valor).
 
 */

// > CREAR DICCIONARIO. Se definen usando corchetes [:] indicando el tipo de la clave y el del valor.

var dicc:[String: Any] = ["Name" : "Mafer", "Age": 20, "ImHappy" : true, "Adreess" : "Calle mi casa", "Phone" : 5514141414] // Any significa cualquier cosa, o sea es una String pero yo ya me encargo de darle su valor

// Si yo quiero acceder a una variable debo poner:
var myDiccName = dicc["Name"] as? String  ?? "Karina"// Esto es una conversión, o sea de String Any lo paso a que siii es una String
print(myDiccName)

for (key, value) in dicc{
    print("La clave \(key) contiene \(value)")
}

//-----------------------------------------------------------------------------



var capitales = ["Francia": "París", "Italia": "Roma", "Japón": "Tokio"]

var puntuaciones: [String: Int] = [:] // Diccionario vacío


print(capitales["Francia"]) // Nota importante: Al pedir un valor, Swift devuelve un Opcional, porque la clave podría no existir.

capitales["México"] = "CDMX" // Agregar o actualizar

capitales["Italia"] = nil // Eliminar

for (pais, capital) in capitales {
    print("La capital de \(pais) es \(capital)")
}




//===========================================================
//                        NULABILIDAD
//===========================================================

/**
 Se maneja a través de un concepto llamado Opcionales (Optionals). Un valor no puede ser nulo a menos que tú lo permitas explícitamente.
 
 Representamos la ausencia de valor con la palabra clave nil.
 */

var nulabilidad:String? = nil
print(nulabilidad)
print(nulabilidad ?? "Karina")

func ejemploNil(_ text:String){
    // Me da igual
}

ejemploNil((nulabilidad ?? "Aqui ya le agregamos algo"))
// Si queremos brapear o sea sabemos que si o si hay algo ahí ponemos:
//              | ejemploNil(nulabilidad!)


func ejemploNil1(_ text:String?){
    if let example = text {
        // Con este if comprobamos que no sea nil, que no sea opcional. Así que con eso podemos imprimir los que no estan vacios.
    } else {
        
    }
    
    guard let example2 = text else {
        return
    }
}
