import UIKit

//===========================================================
//                   VARIABLE Y CONSTANTE
//===========================================================

/**
 
 Una variable sirve para almacenar cosas, son -direcciones de memoria-.
 Se divide en tres parte:
 
          📦 var = palabra reservada
          👩🏻‍💻 name = nombre con el que se guardará mi palabra reservada
          📄 info = la informacion que estará en esa variable

Un let es una constante, no se podrá cambiar el valor. Sin embargo las varibles siempre se podrán modificar.

 */



// ------------- NOTA: COMMD +D = Duplica -------------

var greeting = "Hello, playground"
var name = "Fernanda García"
let name2 = "Karina Silva"

print(name)




//===========================================================
//                   TIPOS DE VARIABLES
//===========================================================

// > CHAR. Las variables "char" unicamente permiten un caracter
var symbol:Character = "e" // Para obligar que sea un "char" debo poner : y el tipo (Character).
var symbol2:Character = "\u{2665}" // Ese es un codigo especial para mostrar un caracter, o sea un corazón
print(symbol2)


// > STRING. Soporta todo, puede soportar caracteres, letras, etc.
var dogName:String = "Robin"


// > INT. Es para numeros enteros, y se puede utilizar dependiendo tipo de almacenamiento, sin embargo se recomienda usar solo int.
var year:Int = 2026


// > FLOAT. Float ocupa 32 bits de memoria pero permite números más grandes por los decimales.
var piFloat:Float = 3.141627822038283923 //Soporta hasta 38 decimales pero si lo queremos imprimir puede que no lo imprima todo ya que se encarga de redondearlo.
print(piFloat)


// > DOUBLE. Si queremos algo más avanzado se ocupa ese ya que soporta más digitos.
var piDouble:Double = 3.1416273893283297343242342
print(piDouble)


// > BOOLEAN / BOOL. Solo tiene 2 variables (verdadero | falso)
var imHappy = true
var imSad:Bool = false




//===========================================================
//                   OPERADORES ARITMETICOS
//===========================================================

var a:Int = 5
var b:Int = 6

var suma = a + b //Suma
print(suma)

var resta = suma - b //Resta
print(resta)

b = resta * suma //Multiplicacion
print(b)

var division = b / 2 //Division
print(division)

var module = a % b //Moodulo
print(module)




//===========================================================
//                   OPERADORES ASIGNACION
//===========================================================

var example = 5
example = example + 10
example += 10 // Es exactamente igual a la linea de arriba
print(example)

example -= 10
example *= 10
example /= 10
example %= 10




//===========================================================
//             OPERADORES LÓGICOS Y DE COMPARACIÓN
//===========================================================

let age = 20

let isOlder = age > 18 // Mayor que
let isYounger = age < 18 // Menor que
let isEqual = age == 20 // Igual que
let isNotEqual = age != 20 // No es igual
let isYoungerOrEqual = age <= 18 // Menor o igual
let isOlderOrEqual = age >= 18 // Mayor o igual

print(isYoungerOrEqual) //Devolverá un bool


let isSunny = true
let temperature:Int = 25

let isPleasant:Bool = isSunny && temperature > 25 // > && = AND
let goToBeach:Bool = isSunny || temperature > 24 // > || = OR
let wearHat:Bool = !isSunny // > ! = Lo negamos, quiere decir que en vez de true pasa a false, o sea que si no está soleado no llevamos sombrero
print(wearHat)




//===========================================================
//                       CONVERSIONES
//===========================================================

let integerNumber:Int = 34
let decimaNumber:Double = 25.65

// ------------- NOTA: No se puede sumar distintas variables -------------

let superNumber:Double = Double(integerNumber) + decimaNumber // Para eso convertimos el int a double
let superNumber2:Int = integerNumber + Int(decimaNumber)
print(superNumber)
